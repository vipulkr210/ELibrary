package servlets;


import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Book;
import beans.IssueBook;
import dao.BookDao;
@WebServlet("/ReturnBook")
public class ReturnBook extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>Return Book</title>");
		out.println("<link rel='stylesheet' href='bootstrap.min.css'/>");
		out.println("</head>");
		out.println("<body>");
		request.getRequestDispatcher("format.jsp").include(request, response);
		request.getRequestDispatcher("sidebarlibrarian.jsp").include(request, response);
			String callno=request.getParameter("callno");
		String sstudentid=request.getParameter("studentid");
		String fin=request.getParameter("fine");
		String id=request.getParameter("id");
			String s=request.getParameter("s");
		int i=0;
		if(s!=null) {if(s.equals("return")) {
			i=BookDao.returnBook(Integer.parseInt(callno),sstudentid,fin,id);
			
		if(i>0){
			out.println("<h3>Book returned successfully</h3>");
			response.sendRedirect("ReturnSucccess?book_id="+callno);
		}else{
			out.println("<h3>Sorry, unable to return book.</h3><p>We may have sortage of books. Kindly visit later.</p>");
		}
		}}
		List<IssueBook> list=BookDao.getIssuedBookbyId(sstudentid);
		out.println("<table class='table table-bordered table-striped'>");
		out.println("<tr><th style='width:30px;'>Callno</th><th>Student Id</th><th>Student Name</th><th>Student Mobile</th><th>Issued Date</th><th>To Be Return on</th><th>Available Days</th><th>Return Status</th><th>Fine Days</th></tr>");
		
		for(IssueBook bean:list){
			DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd MMM yyyy");
			LocalDate l=LocalDate.now();
			LocalDate n=LocalDate.parse(bean.getReturnddate(),dtf);
			long fine=0;
			
			boolean b=false;
			
			if(n.isBefore(l)) {
				if(bean.getReturnstatus().equals("yes")) {}
				fine=java.time.temporal.ChronoUnit.DAYS.between(l,n);
				}else {fine=0;}
			
		
			out.println("<tr><td style='width:30px;'>"+bean.getCallno()+"</td><td>"+bean.getStudentid()+"</td><td>"+bean.getStudentname()+"</td>"
					+ "<td>"+bean.getStudentmobile()+"</td><td>"+bean.getIssueddate()+"</td><td>"+bean.getReturnddate()+"</td>"
					+ "<td>"+java.time.temporal.ChronoUnit.DAYS.between(l,n)+"</td><td>"+bean.getReturnstatus()+"</td><td>"+((-1)*fine)+"</td><td>Rs. "+(fine*(-2))+"</td>");
			out.println("<td><a href='ReturnBook?id="+bean.getId()+"&s=return&studentid="+bean.getStudentid()+"&callno="+bean.getCallno()+"&fine="+fine+"'>RETURN</a></td>");
			out.println("</tr>");
				}
		out.println("</table>");
		list.clear();
		
		request.getRequestDispatcher("format2.jsp").include(request, response);
		out.close();
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}
}
