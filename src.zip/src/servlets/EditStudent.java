package servlets;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Librarian;
import beans.Student;
import dao.LibrarianDao;
import dao.StudentDao;
@WebServlet("/EditStudent")
public class EditStudent extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String sid=request.getParameter("id");
		int id=Integer.parseInt(sid);
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String course=request.getParameter("course");
		String courseyear=request.getParameter("courseyear");
		String branch=request.getParameter("branch");
		String mobile=request.getParameter("mobile");
		Student bean=new Student(id,name, course, mobile, courseyear, email, branch);
		StudentDao.updateStudent(bean);
		response.sendRedirect("ViewStudent");
	}

}
