package servlets;


import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalUnit;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Book;
import beans.IssueBook;
import beans.Student;
import dao.BookDao;
import dao.StudentDao;
@WebServlet("/IssueBook")
public class IssueBooks extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		String callno=request.getParameter("callno");
		String t=request.getParameter("t");
		String id=request.getParameter("id");
		String studentid=request.getParameter("studentid");
		String studentname=request.getParameter("studentname");
		String studentmobile=request.getParameter("studentmobile");
		
		if(t!=null) {
			if(t.equals("find"))
			{BookDao bd=new BookDao();
			List<Book> l=bd.getIssuedbyId(Integer.parseInt(callno));
			List<Student> ls=StudentDao.viewById(Integer.parseInt(id));
			request.setAttribute("book", l);
			request.setAttribute("student", ls);
				RequestDispatcher rd=request.getRequestDispatcher("issuebookform.jsp");
				rd.forward(request, response);
			}
		
		if(t.equals("issue"))
		{Date d= new Date();SimpleDateFormat sdf= new SimpleDateFormat("dd MMM yyyy");
		int d1=Integer.parseInt(new SimpleDateFormat("dd").format(d));
		int m1=Integer.parseInt(new SimpleDateFormat("MM").format(d));
		int y1=Integer.parseInt(new SimpleDateFormat("yyyy").format(d));
		LocalDate today=LocalDate.of(y1, m1,d1);
		LocalDate nextdate=today.plus(1,ChronoUnit.WEEKS);
		DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd MMM yyyy");
				
		IssueBook bean=new IssueBook(Integer.parseInt(callno),studentid,studentname,studentmobile,sdf.format(d),dtf.format(nextdate),"NO","0");
		int i=0;
		i=BookDao.issueBook(bean);
		if(i>0){
			
				RequestDispatcher rd=request.getRequestDispatcher("issuebookform.jsp");rd.include(request, response);
				out.println("<h3>Book issued successfully</h3>");
				}else{
			out.println("<h3>Sorry, unable to issue book.</h3><p>We may have sortage of books. Kindly visit later.</p>");
			RequestDispatcher rd=request.getRequestDispatcher("issuebookform.jsp");rd.include(request, response);
			}
		
		
		//request.getRequestDispatcher("footer.html").include(request, response);
		out.close();
		}
		}
	}

}
