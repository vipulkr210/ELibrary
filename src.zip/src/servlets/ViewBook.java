package servlets;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Book;
import beans.Librarian;
import dao.BookDao;
import dao.LibrarianDao;
@WebServlet("/ViewBook")
public class ViewBook extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>View Book</title>");
		out.println("<link rel='stylesheet' href='bootstrap.min.css'/>  <script src='js/jquery-1.12.4.js'></script><script src='js/jquery.dataTables.min.js'></script><link href='css/datatable.css' rel='stylesheet' /><script> $(document).ready(function() {       $('#example').DataTable();    } );     </script>");
		out.println("</head>");
		out.println("<body>");

		request.getRequestDispatcher("format.jsp").include(request, response);
		request.getRequestDispatcher("sidebarlibrarian.jsp").include(request, response);
		request.getRequestDispatcher("view.jsp").include(request, response);
		List<Book> list=BookDao.view();
		
		out.println("<table class='display table table-bordered table-striped'  border='1'   id='example' >");
			out.println("<thead><tr><th style='width:30px;'>Callno</th><th>Name</th><th>Author</th><th>Publisher</th><th>Quantity</th><th>Issued</th><th>Delete</th></tr></thead>");
		out.println("<tfoot><tr><th style='width:30px;'>Callno</th><th>Name</th><th>Author</th><th>Publisher</th><th>Quantity</th><th>Issued</th><th>Delete</th></tr></tfoot>");
		for(Book bean:list){
			out.println("<tr><td style='width:30px;'>"+bean.getCallno()+"</td><td>"+bean.getName()+"</td><td>"+bean.getAuthor()+"</td><td>"+bean.getPublisher()+"</td><td>"+bean.getQuantity()+"</td><td>"+bean.getIssued()+"</td><td><a href='DeleteBook?callno="+bean.getCallno()+"'>Delete</a></td></tr>");
		}
		out.println("</table>");
		
		
		
		request.getRequestDispatcher("format2.jsp").include(request, response);
		out.close();
	}
}
