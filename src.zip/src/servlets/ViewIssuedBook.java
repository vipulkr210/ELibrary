package servlets;


import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Book;
import beans.IssueBook;
import dao.BookDao;
@WebServlet("/ViewIssuedBook")
public class ViewIssuedBook extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>View Issued Book</title>");
		out.println("<link rel='stylesheet' href='bootstrap.min.css'/>  <script src='js/jquery-1.12.4.js'></script><script src='js/jquery.dataTables.min.js'></script><link href='css/datatable.css' rel='stylesheet' /><script> $(document).ready(function() {       $('#example').DataTable();    } );     </script>");
		out.println("</head>");
		out.println("<body>");
		request.getRequestDispatcher("format.jsp").include(request, response);
		request.getRequestDispatcher("sidebarlibrarian.jsp").include(request, response);
		request.getRequestDispatcher("view.jsp").include(request, response);
			
		List<IssueBook> list=BookDao.viewIssuedBooks();
		
		out.println("<table class='display table table-bordered table-striped'  border='1'   id='example' >");
		out.println("<thead><tr><th style='width:30px;'>Callno</th><th>Student Id</th><th>Student Name</th><th>Student Mobile</th><th>Issued Date</th><th>To Be Return on</th><th>Available Days</th><th>Return Status</th><th>Fine Days</th></tr></thead>");
		out.println("<tfoot><tr><th style='width:30px;'>Callno</th><th>Student Id</th><th>Student Name</th><th>Student Mobile</th><th>Issued Date</th><th>To Be Return on</th><th>Available Days</th><th>Return Status</th><th>Fine Days</th></tr></tfoot>");
		for(IssueBook bean:list){
			DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd MMM yyyy");
			LocalDate ld=LocalDate.of(2018, 01, 12);
			LocalDate l=LocalDate.now();
			LocalDate n=LocalDate.parse(bean.getReturnddate(),dtf);
			long fine=0;
			boolean b=false;
			if(bean.getReturnstatus().equals("yes")) {fine=Long.parseLong(bean.getFine());b=true;
			}
			
			if(!b) {if(n.isBefore(l)) {
				fine=java.time.temporal.ChronoUnit.DAYS.between(l,n);
				
				}
			else {fine=0;
			}
			}
			
		
			out.println("<tr><td style='width:30px;'>"+bean.getCallno()+"</td><td>"+bean.getStudentid()+"</td><td>"+bean.getStudentname()+"</td>"
					+ "<td>"+bean.getStudentmobile()+"</td><td>"+bean.getIssueddate()+"</td><td>"+bean.getReturnddate()+"</td>"
					+ "<td>"+java.time.temporal.ChronoUnit.DAYS.between(l,n)+"</td><td>"+bean.getReturnstatus()+"</td><td>"+fine+"</td></tr>");
		}
		out.println("</table>");
		
		out.println("</div>");
		
		
		request.getRequestDispatcher("format2.jsp").include(request, response);
		out.close();
	}
}
