package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Query;
import org.hibernate.Session;

import beans.Librarian;

@WebServlet("/ForgotPassword")
public class ForgotPassword extends HttpServlet{
//-------------for mail start----------------
	static  Properties props = new Properties();
	static{
		
		
	        props.put("mail.smtp.auth", "true");
	        props.put("mail.smtp.host", "smtp.gmail.com");
	        props.put("mail.smtp.port", "465");
	        props.put("mail.transport.protocol", "smtp");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.starttls.enable", "true");
	        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");

	}
	//---------------for mail end---------------
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String email=req.getParameter("email");
		boolean b=false;
		 List list = new ArrayList();
		    Session sess = dao.HibernateConnection.getSessionFactory().openSession();
	        Query query = sess.createQuery("from Librarian where email='"+email+"'");
	        
	        list = query.list();
	        String userpassword="",username="";
		        	String subject="E-Library Login Details";
		        	String body="Hello User,<br> Your Username is <br> ";
	 	        	
	        if(list.size()>0) {
	        	b=true;
	        	Iterator<Librarian> i=list.iterator();
 	        	while(i.hasNext()) {
 	        		Librarian u=i.next();
	        	username=u.getEmail();
	        	userpassword=u.getPassword();
 	        	}
 	        	
	        	
	        try{
	    //-----------for mail start---------------------
	        	ServletContext c=getServletContext();
	        	String from=c.getInitParameter("mailid");
	        	String password=c.getInitParameter("password");
				System.out.println("Email too "+email+"  is Sent by  "+from+" . "+password);
    			body=body+"  "+username+" <br> Password :"+userpassword+" <br> Login Now";
	        			javax.mail.Session session = javax.mail.Session.getDefaultInstance(props,
	        					new javax.mail.Authenticator() {
	        					protected PasswordAuthentication
	        					getPasswordAuthentication() {
	        					return new
	        					PasswordAuthentication(from , password);
	        					}});
	        					Message message = new MimeMessage(session);
	        					message.setFrom (new InternetAddress(from ));
	        					message.setRecipients(Message.RecipientType.TO,
	        					InternetAddress.parse(email));
	        					message.setSubject(subject);
	        					message.setContent(body,"text/html");
	        					Transport.send(message);
	        //-------------------for mail end----------------------------					 
	        					System.out.println("Email too "+email+"  is Sent by  "+from+" . ");
	        					
	        		}catch (Exception e) {
						// TODO: handle exception
					}
	        }
	        
	        sess.close();	resp.setContentType("text/html");
			PrintWriter out=resp.getWriter();
			if(b) {
			out.print("<h3>Password Sent Succesfully!</h3>");
			out.print("<br><a href='index.html'>Back To Login</a>");
			}
			else {
				out.print("<h3>Email Not Exists! <br>Please Enter Correct E mail Id</h3>");
				out.print("<br><a href='index.html'>Back To Home</a>");
				
			}
				req.getRequestDispatcher("ForgotPassword.html?sub=1").include(req, resp);
			
				
	}
	
	@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			// TODO Auto-generated method stub
			doGet(req, resp);
		}
}
