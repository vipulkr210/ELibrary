package servlets;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Book;
import beans.IssueBook;
import beans.Librarian;
import dao.BookDao;
import dao.LibrarianDao;
@WebServlet("/ViewBookRecord")
public class ViewBookRecord extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String book_id=request.getParameter("book_id");
		String book_name=request.getParameter("book_name");
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>View Book</title>");
		out.println("<link rel='stylesheet' href='bootstrap.min.css'/>");
		out.println("</head>");
		out.println("<body>");
		request.getRequestDispatcher("format.jsp").include(request, response);
		request.getRequestDispatcher("sidebarlibrarian.jsp").include(request, response);
		request.getRequestDispatcher("view.jsp").include(request, response);
		
		List<IssueBook> list=BookDao.view(book_id);
		
		out.println("<h3>"+book_name+"</h3>");
		out.println("<table class='table table-bordered table-striped'>");
		out.println("<tr><th>Callno</th><th>Issued Date</th><th>Return Date</th><th>Return ON</th><th>Issued To</th><th>Mobile</th><th>Return status</th><th>Fine Days</th><th>Fine Amount</th></tr>");
		for(IssueBook bean:list){
			out.println("<tr><td>"+bean.getCallno()+"</td><td>"+bean.getIssueddate()+"</td>"
					+ "<td>"+bean.getReturnddate()+"</td><td>"+bean.getReturnondate()+"</td><td>"+bean.getStudentname()+"</td>"
							+ "<td>"+bean.getStudentmobile()+"</td><td>"+bean.getReturnstatus()+"</td>"
					+ "<td>"+bean.getFine()+"</td><td>Rs."+bean.getFineamount()+"</td></tr>");
		}
		out.println("</table>");
		
		request.getRequestDispatcher("format2.jsp").include(request, response);
		out.close();
	}
}
