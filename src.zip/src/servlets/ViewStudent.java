package servlets;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import beans.Librarian;
import beans.Student;
import dao.LibrarianDao;
import dao.StudentDao;
@WebServlet("/ViewStudent")
public class ViewStudent extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.print("<!DOCTYPE html>");
		out.print("<html>");
		out.println("<head>");
		out.println("<title>View Students</title>");
		out.println("<link rel='stylesheet' href='bootstrap.min.css'/>");
		out.println("</head>");
		out.println("<body>");
		request.getRequestDispatcher("format.jsp").include(request, response);
		request.getRequestDispatcher("sidebarlibrarian.jsp").include(request, response);
		
		
		List<Student> list=StudentDao.view();
		
		out.println("<table class='display table table-bordered table-striped'  border='1'   id='example' >");
		out.println("<thead><tr><th>Id</th><th>Name</th><th>Course</th><th>Course Year</th><th>Email</th><th>Mobile</th><th>Edit</<th><th>Delete</th></tr></thead>");
		out.println("<tfoot><tr><th>Id</th><th>Name</th><th>Course</th><th>Course Year</th><th>Email</th><th>Mobile</th><th>Edit</<th><th>Delete</th></tr></tfoot>");
		for(Student bean:list){
			out.println("<tr><td>"+bean.getId()+"</<td><td>"+bean.getName()+"</td><td>"+bean.getCourse()+"</td><td>"+bean.getCourseyear()+"</td><td>"+bean.getEmail()+"</td><td>"+bean.getMobile()+"</td><td><a href='EditStudentForm?id="+bean.getId()+"'>Edit</a></td><td><a href='DeleteStudent?id="+bean.getId()+"'>Delete</a></td></tr>");
		}
		out.println("</table>");
		request.setAttribute("lo", list);
		request.setAttribute("id", "4");
		
		request.getRequestDispatcher("format2.jsp").include(request, response);
		RequestDispatcher rd=request.getRequestDispatcher("view.jsp");rd.include(request, response);
		
		out.close();
		
	}
}
