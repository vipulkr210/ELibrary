package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import beans.Book;
import beans.IssueBook;
import beans.Librarian;

public class BookDao {

	public static int save(Book bean){
		int status=0;
		try{
			
			Session sess=HibernateConnection.getSessionFactory().openSession();
			sess.save(bean);
			sess.beginTransaction().commit();
			status=1;
			sess.close();
		
			
		}catch(Exception e){System.out.println(e);}
		
		return status;
	}
	
	public static List<Book> view(){
		List<Book> list=new ArrayList<Book>();
		try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from e_book");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Book bean=new Book();
				bean.setCallno(rs.getInt("callno"));
				bean.setName(rs.getString("name"));
				bean.setAuthor(rs.getString("author"));
				bean.setPublisher(rs.getString("publisher"));
				bean.setQuantity(rs.getInt("quantity"));
				bean.setIssued(rs.getInt("issued"));
				
				list.add(bean);
			}
			con.close();
			
		}catch(Exception e){System.out.println(e);}
		
		return list;
	}
	public static int delete(String callno){
		int status=0;
		try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("delete from e_book where callno=?");
			ps.setString(1,callno);
			status=ps.executeUpdate();
			con.close();
			
		}catch(Exception e){System.out.println(e);}
		
		return status;
	}
	public static int getIssued(int callno){
		int issued=0;
		try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from e_book where callno=?");
			ps.setInt(1,callno);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				issued=rs.getInt("issued");
			}
			con.close();
			
		}catch(Exception e){System.out.println(e);}
		
		return issued;
	}
	public  List<Book> getIssuedbyId(int callno){
		int issued=0;
		List<Book> list=new ArrayList<>();
		try{
			Session sess=HibernateConnection.getSessionFactory().openSession();
			Query q=sess.createQuery("From Book where callno='"+callno+"'");
			 list=q.list();
			
		}catch(Exception e){System.out.println(e);}
		
		return list;
	}
	public static List<IssueBook> getIssuedBookbyId(String id){
		int issued=0;
		List<IssueBook> list=new ArrayList<>();
		try{
			Session sess=HibernateConnection.getSessionFactory().openSession();
			Query q=sess.createQuery("From IssueBook where studentid='"+id+"' and returnstatus='no'");
			 list=q.list();
			
		}catch(Exception e){System.out.println(e);}
		
		return list;
	}
	public static boolean checkIssue(int callno){
		boolean status=false;
		try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from e_book where callno=? and quantity>issued");
			ps.setInt(1,callno);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				status=true;
			}
			con.close();
			
		}catch(Exception e){System.out.println(e);}
		
		return status;
	}
	public static int issueBook(IssueBook bean){
		int callno=bean.getCallno();
		boolean checkstatus=checkIssue(callno);
		System.out.println("Check status: "+checkstatus);
		if(checkstatus){
			int status=0;
			try{
				Session sess=HibernateConnection.getSessionFactory().openSession();
				sess.save(bean);
				sess.beginTransaction().commit();
				status=1;
				sess.close();
				
				
				if(status>0){
					Session sess1=HibernateConnection.getSessionFactory().openSession();
					
					Book b=(Book)sess1.load(Book.class, bean.getCallno());
							b.setIssued(getIssued(callno)+1);;
							sess1.update(b);
					sess1.beginTransaction().commit();
					status=1;
					sess1.close();
				}
				
			}catch(Exception e){System.out.println(e);}
			
			return status;
		}else{
			return 0;
		}
	}
	public static int returnBook(int callno,String studentid,String fine, String id){
		int status=0;
			try{
				Connection con=DB.getCon();
				Date d= new Date();SimpleDateFormat sdf= new SimpleDateFormat("dd MMM yyyy");
				List<IssueBook> list=new ArrayList<>();
				try{
					Session sess=HibernateConnection.getSessionFactory().openSession();
					Query q=sess.createQuery("From IssueBook where id='"+id+"' and returnstatus='no'");
					 list=q.list();
					
				}catch(Exception e){System.out.println(e);}
				
				System.out.println("Issued Book "+list.size());
				
				if(list.size()>0) {
				PreparedStatement ps=con.prepareStatement("update e_issuebook set returnstatus='yes',fine=?,fineamount=?,returnondate=? where id=?");
				ps.setString(1,fine);
				ps.setInt(2,(Integer.parseInt(fine)*(-2)));
				ps.setString(3,sdf.format(d));
				ps.setInt(4,Integer.parseInt(id));
				
				status=ps.executeUpdate();
				if(status>0){
					PreparedStatement ps2=con.prepareStatement("update e_book set issued=? where callno=?");
					ps2.setInt(1,(getIssued(callno)-1));
					ps2.setInt(2,callno);
					status=ps2.executeUpdate();
					System.out.println("Books In Library : "+(getIssued(callno)));
				}
				con.close();
				}
			}catch(Exception e){e.printStackTrace();}
			
			return status;
	}
	public static List<IssueBook> viewIssuedBooks(){
		List<IssueBook> list=new ArrayList<IssueBook>();
		try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from e_issuebook where returnstatus!='yes' order by issueddate desc");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				IssueBook bean=new IssueBook();
				bean.setCallno(rs.getInt("callno"));
				bean.setStudentid(rs.getString("studentid"));
				bean.setStudentname(rs.getString("studentname"));
				bean.setStudentmobile(rs.getString("studentmobile"));
				bean.setIssueddate(rs.getString("issueddate"));
				bean.setReturnstatus(rs.getString("returnstatus"));
				bean.setReturnddate(rs.getString("returnddate"));
				bean.setFine(rs.getString("fine"));
				list.add(bean);
			}
			con.close();
			
		}catch(Exception e){System.out.println(e);}
		
		return list;
	}
	public static List<IssueBook> view(String book_id) {
		List<IssueBook> list=new ArrayList<IssueBook>();
		try{
			Connection con=DB.getCon();
			PreparedStatement ps=con.prepareStatement("select * from e_issuebook where callno='"+book_id+"' order by issueddate");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				IssueBook bean=new IssueBook();
				bean.setCallno(rs.getInt("callno"));
				bean.setStudentid(rs.getString("studentid"));
				bean.setStudentname(rs.getString("studentname"));
				bean.setStudentmobile(rs.getString("studentmobile"));
				bean.setIssueddate(rs.getString("issueddate"));
				bean.setReturnstatus(rs.getString("returnstatus"));
				bean.setReturnddate(rs.getString("returnddate"));
				bean.setReturnondate(rs.getString("returnondate"));
				bean.setFine(rs.getString("fine"));
				bean.setFineamount(rs.getInt("fineamount"));
				list.add(bean);
			}
			con.close();
			
		}catch(Exception e){System.out.println(e);}
		
		return list;
	}	
}
