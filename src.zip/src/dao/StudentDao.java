package dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import beans.Student;
public class StudentDao {

	public static int save(Student bean){
		int status=0;
		try{
			
			Session sess=HibernateConnection.getSessionFactory().openSession();
			sess.save(bean);
			sess.beginTransaction().commit();
			status=1;
			sess.close();
		}catch(Exception e){System.out.println(e);}
		
		return status;
	}
	public static List<Student> view(){
		List<Student> list=new ArrayList<Student>();
		try{
			Query query=HibernateConnection.getSessionFactory().openSession().createQuery("from Student");
			list=query.list();
		}catch(Exception e){e.printStackTrace();}
		
		return list;
	}
	public static int delete(int id){
		int status=0;
		try{
			Session sess=HibernateConnection.getSessionFactory().openSession();
			Student s=(Student)sess.load(Student.class, id);
			sess.delete(s);
			sess.beginTransaction().commit();
			sess.close();
			status=1;			
		}catch(Exception e){System.out.println(e);}
		
		return status;
	}
	public static int updateStudent(Student bean) {
		int status=0;
		try{
			Session sess=HibernateConnection.getSessionFactory().openSession();
			Student s=(Student)sess.load(Student.class, bean.getId());
			sess.update(bean);
			sess.beginTransaction().commit();
			sess.close();
			status=1;			
		}catch(Exception e){System.out.println(e);}
		
		return status;
	}
	public static List<Student> viewById(int id) {
		 List list=null;
		 try{
			Session sess=HibernateConnection.getSessionFactory().openSession();
			Query s=sess.createQuery("From Student where id='"+id+"'");
			list=s.list();
			sess.beginTransaction().commit();
			sess.close();
				
		}catch(Exception e){System.out.println(e);}
		
		
		return list;
		
	}
	
}
