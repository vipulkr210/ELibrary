package beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="Student")
public class Student {
	
	@Id @GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String name,course,mobile,courseyear,email,branch;
	
	public Student() {
		
	}
	public Student(int id, String name, String course, String mobile, String courseyear, String email, String branch) {
		super();
		this.id = id;
		this.name = name;
		this.course = course;
		this.mobile = mobile;
		this.courseyear = courseyear;
		this.email = email;
		this.branch = branch;
	}
	public Student(String name, String course, String mobile, String courseyear, String email, String branch) {
		super();
		this.name = name;
		this.course = course;
		this.mobile = mobile;
		this.courseyear = courseyear;
		this.email = email;
		this.branch = branch;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getCourseyear() {
		return courseyear;
	}
	public void setCourseyear(String courseyear) {
		this.courseyear = courseyear;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	
	

}
