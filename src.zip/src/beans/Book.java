package beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="e_book")
public class Book {
	@Id @GeneratedValue(strategy=GenerationType.AUTO)
	private int callno;
	private String name,author,publisher;
private int quantity,issued;
public Book() {
	super();
	// TODO Auto-generated constructor stub
}
public Book(String name, String author, String publisher, int quantity) {
	super();
	this.name = name;
	this.author = author;
	this.publisher = publisher;
	this.quantity = quantity;
}
public int getCallno() {
	return callno;
}
public void setCallno(int callno) {
	this.callno = callno;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAuthor() {
	return author;
}
public void setAuthor(String author) {
	this.author = author;
}
public String getPublisher() {
	return publisher;
}
public void setPublisher(String publisher) {
	this.publisher = publisher;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public int getIssued() {
	return issued;
}
@Column(columnDefinition="int(5) default 0")
public void setIssued(int issued) {
	this.issued = issued;
}

}
