package beans;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity @Table(name="e_issuebook")
public class IssueBook {

	@Id @GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private int callno;
private String studentid,studentname;
private String studentmobile;
private String issueddate;
private String returnddate;
private String fine;
private String returnstatus;


public IssueBook() {}

public IssueBook(int callno, String studentid, String studentname, String studentmobile, String issueddate,String returndate,String returnstatus,String fine) {
	super();
	this.callno = callno;
	this.studentid = studentid;
	this.studentname = studentname;
	this.studentmobile = studentmobile;
	this.issueddate = issueddate;
	this.returnddate=returndate;
	this.fine=fine;
	this.returnstatus=returnstatus;
}

public IssueBook(int callno, String studentid, String studentname, String studentmobile) {
	super();
	this.callno = callno;
	this.studentid = studentid;
	this.studentname = studentname;
	this.studentmobile = studentmobile;
}

public int getId() {
	return id;
}

public String getFine() {
	return fine;
}

public void setFine(String fine) {
	this.fine = fine;
}

public void setId(int id) {
	this.id = id;
}

public String getReturnddate() {
	return returnddate;
}

public void setReturnddate(String returnddate) {
	this.returnddate = returnddate;
}

public String getReturnstatus() {
	return returnstatus;
}
@Column(columnDefinition="varchar(30) default '0'")
public void setReturnstatus(String returnstatus) {
	this.returnstatus = returnstatus;
}
public String getIssueddate() {
	return issueddate;
}
public void setIssueddate(String issueddate) {
	this.issueddate = issueddate;
}
public int getCallno() {
	return callno;
}
public void setCallno(int callno) {
	this.callno = callno;
}
public String getStudentid() {
	return studentid;
}
public void setStudentid(String studentid) {
	this.studentid = studentid;
}
public String getStudentname() {
	return studentname;
}
public void setStudentname(String studentname) {
	this.studentname = studentname;
}
public String getStudentmobile() {
	return studentmobile;
}
public void setStudentmobile(String studentmobile) {
	this.studentmobile = studentmobile;
}

}
